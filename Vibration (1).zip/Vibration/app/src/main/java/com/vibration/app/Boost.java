package com.vibration.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.os.Process;
import java.util.List;

public final class Boost {
    private Boost() {}

    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences("vibration", 0); }
    public static boolean enabled(Context c) { return prefs(c).getBoolean("boost", true); }

    public static long totalMb(Context c) {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m);
        return m.totalMem / 1048576L;
    }
    public static long freeMb(Context c) {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m);
        return m.availMem / 1048576L;
    }
    /** Marketing "6 GB" phones report ~5.4-5.9 GB usable. */
    public static boolean is6GbClass(Context c) { return totalMb(c) >= 5200; }

    /** Frees RAM and raises this process priority. Run right before launching the game. */
    public static void apply(Context c) {
        if (!enabled(c)) return;
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY); } catch (Throwable ignored) {}
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ApplicationInfo> apps = c.getPackageManager().getInstalledApplications(0);
        for (ApplicationInfo a : apps) {
            if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (a.packageName.equals(c.getPackageName())) continue;
            try { am.killBackgroundProcesses(a.packageName); } catch (Throwable ignored) {}
        }
        System.gc();
    }
}
