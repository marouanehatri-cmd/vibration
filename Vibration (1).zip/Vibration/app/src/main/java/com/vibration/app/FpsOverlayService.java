package com.vibration.app;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/** Shows display frame rate + free RAM. Measures the screen's frame cadence (not the game's internal render rate). */
public class FpsOverlayService extends Service implements Choreographer.FrameCallback {
    private WindowManager wm; private TextView tv;
    private long last; private int frames;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        NotificationChannel ch = new NotificationChannel("vib", "Vibration", NotificationManager.IMPORTANCE_MIN);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        startForeground(1, new Notification.Builder(this, "vib").setContentTitle("Vibration overlay")
                .setSmallIcon(android.R.drawable.ic_menu_info_details).build());
        if (tv == null && Settings.canDrawOverlays(this)) {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            tv = new TextView(this);
            tv.setTextColor(Color.GREEN); tv.setTextSize(12); tv.setBackgroundColor(0x88000000); tv.setPadding(12, 4, 12, 4);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-2, -2,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            wm.addView(tv, lp);
            Choreographer.getInstance().postFrameCallback(this);
        }
        return START_NOT_STICKY;
    }

    @Override public void doFrame(long ns) {
        if (tv == null) return;
        if (last == 0) last = ns;
        frames++;
        if (ns - last >= 1_000_000_000L) {
            tv.setText(frames + " FPS | " + Boost.freeMb(this) + " MB free");
            frames = 0; last = ns;
        }
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override public void onDestroy() {
        if (tv != null) { try { wm.removeView(tv); } catch (Throwable ignored) {} tv = null; }
        super.onDestroy();
    }
}
