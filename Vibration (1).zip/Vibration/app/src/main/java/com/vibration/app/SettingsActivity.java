package com.vibration.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

public class SettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.column(this); setContentView(root);
        root.addView(Ui.text(this, "Settings", 26, 0xFFFFFFFF));

        root.addView(sw("Vibration Boost", "boost", true));
        root.addView(sw("FPS / RAM overlay", "fps_overlay", false));

        LinearLayout perf = Ui.card(this);
        perf.addView(Ui.text(this, "FPS: 60FPS (locked)", 16, 0xFFFFFFFF));
        perf.addView(Ui.text(this, "Resolution 85%  •  Graphics Standard  •  OpenGL", 13, 0xFFB0B0C8));
        root.addView(perf);

        LinearLayout acc = Ui.card(this);
        acc.addView(Ui.text(this, "Google account (internal Play Store)", 16, 0xFFFFFFFF));
        acc.addView(Ui.text(this, "GmsCore: " + yn(Space.has(Space.GMS)) + "   GSF proxy: " + yn(Space.has(Space.GSF))
                + "   Play Store: " + yn(Space.has(Space.STORE)), 13, 0xFFB0B0C8));
        boolean signed = Boost.prefs(this).getBoolean("signed_in", false);
        acc.addView(Ui.text(this, signed ? "Signed in (confirmed by you)" : "Not signed in", 14, signed ? 0xFF4ADE80 : 0xFFFBBF24));
        acc.addView(Ui.button(this, signed ? "Mark as signed out" : "I signed in inside the Play Store", 0xFF334155, v -> {
            Boost.prefs(this).edit().putBoolean("signed_in", !signed).apply(); recreate();
        }));
        root.addView(acc);

        LinearLayout ram = Ui.card(this);
        ram.addView(Ui.text(this, "RAM info", 16, 0xFFFFFFFF));
        ram.addView(Ui.text(this, "Total " + Boost.totalMb(this) + " MB  •  Free " + Boost.freeMb(this) + " MB  •  "
                + (Boost.is6GbClass(this) ? "6 GB profile detected" : "below 6 GB profile"), 13, 0xFFB0B0C8));
        root.addView(ram);
    }

    private static String yn(boolean b) { return b ? "yes" : "no"; }

    private Switch sw(String label, String key, boolean def) {
        Switch s = new Switch(this); s.setText(label); s.setTextColor(0xFFFFFFFF); s.setTextSize(16);
        s.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        s.setChecked(Boost.prefs(this).getBoolean(key, def));
        s.setOnCheckedChangeListener((v, on) -> Boost.prefs(this).edit().putBoolean(key, on).apply());
        return s;
    }
}
