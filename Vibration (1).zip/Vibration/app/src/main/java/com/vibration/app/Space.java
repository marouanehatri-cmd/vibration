package com.vibration.app;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
import java.io.File;

/** Thin wrapper around the virtual space (user 0). Everything here happens INSIDE the space. */
public final class Space {
    public static final int USER = 0;
    public static final String GMS = "com.google.android.gms";        // microG GmsCore
    public static final String GSF = "com.google.android.gsf";        // microG Services Framework Proxy
    public static final String STORE = "com.android.vending";          // real Play Store
    public static final String GAME = "com.konami.efootballpes";

    private Space() {}

    public static boolean has(String pkg) {
        try { return BlackBoxCore.get().isInstalled(pkg, USER); } catch (Throwable t) { return false; }
    }

    public static boolean googleReady() { return has(GMS) && has(GSF) && has(STORE); }

    /** Install an APK file into the space. Installing over an existing package keeps its data. */
    public static String install(File apk) {
        try {
            InstallResult r = BlackBoxCore.get().installPackageAsUser(apk, USER);
            return r.success ? null : String.valueOf(r.msg);
        } catch (Throwable t) { return t.toString(); }
    }

    /** Clone the host-installed eFootball into the space (user must own it on the host first). */
    public static String cloneFromHost(String pkg) {
        try {
            InstallResult r = BlackBoxCore.get().installPackageAsUser(pkg, USER);
            return r.success ? null : String.valueOf(r.msg);
        } catch (Throwable t) { return t.toString(); }
    }

    public static boolean launch(String pkg) {
        try { return BlackBoxCore.get().launchApk(pkg, USER); } catch (Throwable t) { return false; }
    }

    /** Opens the Play Store page of a package inside the space (update button lives there). */
    public static boolean openStorePage(Context c, String pkg) {
        if (!has(STORE)) return false;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
            i.setPackage(STORE);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            BlackBoxCore.getBActivityManager().startActivity(i, USER);
            return true;
        } catch (Throwable t) { return launch(STORE); }
    }
}
