package com.vibration.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;

/** Tiny programmatic UI helpers (no XML layouts = smaller APK). */
final class Ui {
    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density); }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16); l.setPadding(p, p, p, p); l.setBackgroundColor(0xFF000000); return l;
    }
    static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setPadding(0, dp(c, 4), 0, dp(c, 4)); return t;
    }
    static Button button(Context c, String s, int bg, View.OnClickListener l) {
        Button b = new Button(c); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setOnClickListener(l);
        GradientDrawable g = new GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(c, 12)); b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c, 52)); lp.topMargin = dp(c, 8); b.setLayoutParams(lp);
        return b;
    }
    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16); l.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF171726); g.setCornerRadius(dp(c, 16)); l.setBackground(g);
        return l;
    }
}
