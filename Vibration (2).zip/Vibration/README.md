# Vibration
Virtual space for eFootball on Huawei Y8p (no GMS). Engine: NewBlackbox (github.com/ALEX5402/NewBlackbox),
fetched and built by the GitHub workflow (the project cannot be built alone, it needs the engine module).

Build: upload Vibration.zip to the repo root, Actions builds Vibration.apk.
The workflow prints the engine commit used; pin that commit in build.yml once a build works (supply-chain safety).

Google Play inside the space: import microG GmsCore, microG Services Framework Proxy (com.google.android.gsf)
and an official Play Store APK with "Import APK into space", then sign in inside the Play Store.
Whether the real Play Store accepts microG depends on signature spoofing inside the engine; this is not guaranteed.
Test with a spare Google account first.
