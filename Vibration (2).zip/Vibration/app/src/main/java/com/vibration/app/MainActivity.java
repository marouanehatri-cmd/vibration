package com.vibration.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_APK = 10;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        build();
    }
    @Override protected void onResume() { super.onResume(); build(); }

    private void build() {
        LinearLayout root = Ui.column(this);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.setBackgroundColor(0xFF000000); sv.addView(root);
        setContentView(sv);

        root.addView(Ui.text(this, "Vibration", 28, 0xFFFFFFFF));
        root.addView(Ui.text(this, "Virtual space  \u2022  Huawei compatible", 12, 0xFF8A8AA8));

        LinearLayout card = Ui.card(this);
        boolean game = Space.has(Space.GAME);
        card.addView(Ui.text(this, "eFootball", 20, 0xFFFFFFFF));
        card.addView(Ui.text(this, game ? "Version " + Space.version(Space.GAME) : "Not in the space yet", 14, 0xFFB0B0C8));
        boolean ok = Boost.is6GbClass(this);
        card.addView(Ui.text(this, ok ? "60FPS Ready  \u2022  " + Boost.totalMb(this) + " MB RAM" : "RAM below 6 GB profile", 14, ok ? 0xFF4ADE80 : 0xFFFBBF24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = Ui.dp(this, 16);
        card.setLayoutParams(lp);
        root.addView(card);

        root.addView(Ui.button(this, "Launch Game", 0xFF7C3AED, v -> launchGame()));
        root.addView(Ui.button(this, "Open Play Store", 0xFF2563EB, v -> {
            if (!Space.googleReady()) { toast("Google components missing: use 'Import APK into space' (see README)."); return; }
            if (!Space.launch(Space.STORE)) toast("Play Store did not start.");
        }));
        root.addView(Ui.button(this, "Check for Update", 0xFF0EA5E9, v -> {
            if (!Space.openStorePage(this, Space.GAME)) toast("Play Store is not installed in the space yet.");
        }));
        root.addView(Ui.button(this, "Install APK as Update", 0xFF334155, v -> pickApk()));
        root.addView(Ui.button(this, "Import APK into space (microG / Play Store)", 0xFF334155, v -> pickApk()));
        if (!game) root.addView(Ui.button(this, "Copy eFootball from this phone", 0xFF334155, v -> {
            String err = Space.cloneFromHost(Space.GAME);
            toast(err == null ? "Done" : "Failed: " + err); build();
        }));
        root.addView(Ui.button(this, "Settings", 0xFF1F2937, v -> startActivity(new Intent(this, SettingsActivity.class))));
    }

    private void launchGame() {
        if (!Space.has(Space.GAME)) { toast("eFootball is not in the space yet."); return; }
        Boost.apply(this);
        if (Boost.prefs(this).getBoolean("fps_overlay", false)) {
            if (!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            else startForegroundService(new Intent(this, FpsOverlayService.class));
        }
        if (!Space.launch(Space.GAME)) toast("Launch failed.");
    }

    private void pickApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, PICK_APK);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK_APK || res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        new Thread(() -> {
            StringBuilder log = new StringBuilder();
            for (Uri u : uris) {
                File f = new File(getCacheDir(), "import.apk");
                try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    String err = Space.install(f);
                    log.append(err == null ? "OK  " : "FAIL " + err + "  ");
                } catch (Throwable t) { log.append("ERR ").append(t.getMessage()).append("  "); }
                f.delete();
            }
            runOnUiThread(() -> { toast(log.toString()); build(); });
        }).start();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
