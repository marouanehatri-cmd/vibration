package com.vibration.app;

import java.lang.reflect.Method;

/** Reflection helpers so that small API differences in the engine cannot break compilation. */
final class Rf {
    private static final String CORE = "top.niunaijun.blackbox.BlackBoxCore";
    private Rf() {}

    static Object core() throws Exception { return callStatic("get"); }

    static Object callStatic(String name, Object... args) throws Exception {
        return invoke(Class.forName(CORE), null, name, args);
    }
    static Object call(Object target, String name, Object... args) throws Exception {
        return invoke(target.getClass(), target, name, args);
    }
    static Object callCore(String name, Object... args) throws Exception { return call(core(), name, args); }

    private static Object invoke(Class<?> c, Object target, String name, Object[] args) throws Exception {
        for (Method m : c.getMethods()) {
            if (!m.getName().equals(name) || m.getParameterTypes().length != args.length) continue;
            if (!fits(m.getParameterTypes(), args)) continue;
            return m.invoke(target, args);
        }
        throw new NoSuchMethodException(name);
    }
    private static boolean fits(Class<?>[] p, Object[] a) {
        for (int i = 0; i < p.length; i++) {
            if (a[i] == null) continue;
            Class<?> t = p[i];
            if (t.isPrimitive()) {
                if (t == int.class && !(a[i] instanceof Integer)) return false;
                if (t == boolean.class && !(a[i] instanceof Boolean)) return false;
                if (t == long.class && !(a[i] instanceof Long)) return false;
            } else if (!t.isInstance(a[i])) return false;
        }
        return true;
    }

    /** Reads a boolean "success" from an install-result object, whatever the engine calls it. */
    static boolean success(Object r) {
        if (r == null) return false;
        if (r instanceof Boolean) return (Boolean) r;
        try { return (Boolean) r.getClass().getField("success").get(r); } catch (Throwable ignored) {}
        try { return (Boolean) call(r, "isSuccess"); } catch (Throwable ignored) {}
        return true;
    }
    static String message(Object r) {
        if (r == null) return "no result";
        for (String f : new String[]{"msg", "message", "error"}) {
            try { Object v = r.getClass().getField(f).get(r); if (v != null) return String.valueOf(v); } catch (Throwable ignored) {}
        }
        for (String m : new String[]{"getErrorMessage", "getMsg", "getMessage"}) {
            try { Object v = call(r, m); if (v != null) return String.valueOf(v); } catch (Throwable ignored) {}
        }
        return String.valueOf(r);
    }
}
