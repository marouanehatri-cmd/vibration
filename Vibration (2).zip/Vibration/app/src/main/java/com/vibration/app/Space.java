package com.vibration.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import java.io.File;

/** The virtual space (user 0). Everything here happens INSIDE the engine's sandbox. */
public final class Space {
    public static final int USER = 0;
    public static final String GMS = "com.google.android.gms";   // microG GmsCore
    public static final String GSF = "com.google.android.gsf";   // microG Services Framework Proxy
    public static final String STORE = "com.android.vending";     // Google Play Store
    public static final String GAME = "com.konami.efootballpes";

    private Space() {}

    public static boolean has(String pkg) {
        try { return (Boolean) Rf.callCore("isInstalled", pkg, USER); } catch (Throwable t) { return false; }
    }

    public static boolean googleReady() { return has(GMS) && has(GSF) && has(STORE); }

    /** Installs an APK file into the space. Over an existing package it should keep the data. Returns null on success. */
    public static String install(File apk) {
        try {
            Object r = Rf.callCore("installPackageAsUser", apk, USER);
            return Rf.success(r) ? null : Rf.message(r);
        } catch (Throwable t) { return String.valueOf(t); }
    }

    /** Copies a phone-installed app (for example eFootball) into the space. Returns null on success. */
    public static String cloneFromHost(String pkg) {
        try {
            Object r = Rf.callCore("installPackageAsUser", pkg, USER);
            return Rf.success(r) ? null : Rf.message(r);
        } catch (Throwable t) { return String.valueOf(t); }
    }

    public static boolean launch(String pkg) {
        try { return Boolean.TRUE.equals(Rf.callCore("launchApk", pkg, USER)); } catch (Throwable t) { return false; }
    }

    public static String version(String pkg) {
        try {
            Object pm = Rf.callStatic("getBPackageManager");
            PackageInfo pi = (PackageInfo) Rf.call(pm, "getPackageInfo", pkg, 0, USER);
            return pi != null && pi.versionName != null ? pi.versionName : "?";
        } catch (Throwable t) { return "?"; }
    }

    /** Opens an app's page in the Play Store inside the space (the Update button is there). */
    public static boolean openStorePage(Context c, String pkg) {
        if (!has(STORE)) return false;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
            i.setPackage(STORE);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Object am = Rf.callStatic("getBActivityManager");
            Rf.call(am, "startActivity", i, USER);
            return true;
        } catch (Throwable t) { return launch(STORE); }
    }
}
