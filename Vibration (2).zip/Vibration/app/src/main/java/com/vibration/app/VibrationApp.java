package com.vibration.app;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

/** Engine init. Must run in attachBaseContext (host and virtual processes). */
public class VibrationApp extends Application {
    @Override protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {
                @Override public String getHostPackageName() { return base.getPackageName(); }
            });
        } catch (Throwable t) { Log.e("Vibration", "engine attach failed", t); }
    }

    @Override public void onCreate() {
        super.onCreate();
        try { BlackBoxCore.get().doCreate(); }
        catch (Throwable t) { Log.e("Vibration", "engine create failed", t); }
    }
}
